from kpseudothreads import KPseudoThreads 
import os


# read hook - reads the data and before exiting adds once more the read and write threads
def read_thread_hook(thr, w_pipe):
    threads = thr.parent
    data = os.read(thr.socket, 100)
    print ("Received", data)
    threads.add_read_thread("Read", thr.socket, something.read_thread_hook, w_pipe)
    threads.add_write_thread("Write", w_pipe, something.write_thread_hook, thr.socket)
# write thread - sending the data
def write_thread_hook(thr, r_pipe):
    print ("Sending..")
    os.write(thr.socket, b"Something")
# this thread cancels the read and write threads. As there is no more threads left - this will actually break the loop and the program exists drom thread_run()
def timer_thread_hook(thr, arg):
    threads = thr.parent
    r_pipe,w_pipe = arg
    print ("Stop")
    threads.cancel_thread_by_sock(r_pipe)
    threads.cancel_thread_by_sock(w_pipe)

# Pipe
r_pipe,w_pipe = os.pipe()
# create object
threads = KPseudoThreads("Thread", KPseudoThreads.LOG_DBG, KPseudoThreads.LOG_CONSOLE, debug=False)
# add read, write and timer threads
threads.add_read_thread("Read", r_pipe, read_thread_hook, w_pipe)
threads.add_write_thread("Write", w_pipe, write_thread_hook, r_pipe)
threads.add_timer_thread("Timer", 100, timer_thread_hook, (r_pipe,w_pipe))
# run
threads.threads_run();
#close pipes
os.close(r_pipe)
os.close(w_pipe)